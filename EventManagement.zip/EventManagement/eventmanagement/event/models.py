from django.db import models

# Create your models here.


class Room(models.Model):
    roomId = models.IntegerField(primary_key=True)
    roomName=models.CharField(max_length=100)


class Event(models.Model):
    eventId=models.IntegerField(primary_key=True)
    eventTitle=models.CharField(max_length=100)
    room = models.ForeignKey(Room, on_delete=models.CASCADE)