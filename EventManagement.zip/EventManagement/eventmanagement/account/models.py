from django.db import models

# Create your models here.

class User(models.Model):
    username = models.CharField(primary_key=True, max_length=15)
    password = models.CharField(max_length=15)
    firstname = models.CharField(max_length=50)
    lastname = models.CharField(max_length=50)
    type = models.CharField(max_length=1)


class Teacher(User):
    pass


class Student(User):
    course = models.CharField(max_length=15)
    department=models.CharField(max_length=50)

