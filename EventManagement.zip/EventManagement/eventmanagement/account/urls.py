from django.urls import path
from . import views

app='account'

urlpatterns = [
    path('', views.HomeView.as_view(),name='index'),
    path('registerStudent',views.RegisterStudent.as_view(),name='registerstudent')

]