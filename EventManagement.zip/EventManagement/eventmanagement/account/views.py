from django.shortcuts import render
from django.http import HttpResponse
from django.views import View
from .form import   StudentForm


# Create your views here.

class HomeView(View):
    template_name='index.html'

    def get(self,request):
        strName=['Jose']
        return render(request,self.template_name,{'strname':strName})


class RegisterStudent(View):
    template_name='registerStudent.html'

    def get(self,request):
        form = StudentForm()
        return render(request,self.template_name,{'form':form})

    def post(self,request):
        form =StudentForm(request.POST)
        if form.is_valid():
            form.save()
        else:
            print(form.errors)
        return render(request, self.template_name, {'form': form})

